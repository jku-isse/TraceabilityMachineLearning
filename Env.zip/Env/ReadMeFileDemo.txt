install anaconda 
install spyder 
unzip zipfile
open anaconda prompt 
run from the current directory of the unzipped file the command: conda env create -f environment.yml
open the file demo.py in Spyder and go to preferences, Python interpreter, select "use the following python interpreter" and choose file and go to the anaconda, go to envs, spyder, and choose python.exe, 
apply and run 
